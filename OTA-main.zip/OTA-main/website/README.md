# OTA (Upload Over The Air) for STM32F103
you need to upload this files to PHP server or your local server
or you can use this [website](http://iot-arm.freevar.com/) 
*it will expire after 3 months and take about 10 mins to upload as its free server*.

Don't forget to edit ```main.c``` file and flash size
