/*********************************************************************************/
/* Author    : Islam Abdo                                                        */
/* Version   : V01                                                               */
/* Date      : 4  Aug  2021                                                      */
/*********************************************************************************/

#ifndef MAIN_CONFIG_H
#define MAIN_CONFIG_H

#define SSID  				"Islam"
#define PASSWORD 			"islam999"

#define IPserver			"192.168.1.11"


#endif //MAIN_CONFIG_H
