/*********************************************************************************/
/* Author    : Islam Abdo                                                        */
/* Version   : V01                                                               */
/* Date      : 17 OCT  2020                                                      */
/*********************************************************************************/
#ifndef STK_CONFIG_H
#define STK_CONFIG_H




/* Options : STK_SRC_AHB
 * 			 STK_SRC_AHB_8						*/
#define STK_CLOCK_SRC		STK_SRC_AHB_8

#endif /* STK_CONFIG_H */
