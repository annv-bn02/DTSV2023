/*********************************************************************************/
/* Author    : Islam Abdo                                                        */
/* Version   : V01                                                               */
/* Date      : 18 July 2021                                                      */
/*********************************************************************************/

#ifndef FPEC_CONFIG_H
#define FPEC_CONFIG_H

#define BOOTLOADER_SIZE  9

#endif //FPEC_CONFIG_H
